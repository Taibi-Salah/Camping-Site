<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* layouts/partials/_cta_section.html.twig */
class __TwigTemplate_afa1c77c02a858c8b546b69f66882265 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "layouts/partials/_cta_section.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "layouts/partials/_cta_section.html.twig"));

        // line 1
        yield "<section id=\"cta\" class=\"cta\">
      <div class=\"container\" data-aos=\"fade-in\">

        <div class=\"text-center\">
          <h3>Réductions limités jusqu'au 01/08 </h3>
          <p> Nous proposons des tarifs avantageux pour toutes réservations effectués avant le 01/08 .</p>
          <a class=\"cta-btn\" href=\"";
        // line 7
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_price");
        yield "\"> Cliquez-ici pour Réservez </a>
        </div>

      </div>
    </section>";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "layouts/partials/_cta_section.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  52 => 7,  44 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<section id=\"cta\" class=\"cta\">
      <div class=\"container\" data-aos=\"fade-in\">

        <div class=\"text-center\">
          <h3>Réductions limités jusqu'au 01/08 </h3>
          <p> Nous proposons des tarifs avantageux pour toutes réservations effectués avant le 01/08 .</p>
          <a class=\"cta-btn\" href=\"{{ path('app_price') }}\"> Cliquez-ici pour Réservez </a>
        </div>

      </div>
    </section>", "layouts/partials/_cta_section.html.twig", "/home/formatpro/Bureau/Camping Serenity/Camping/templates/layouts/partials/_cta_section.html.twig");
    }
}
