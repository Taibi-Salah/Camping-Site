<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* payment/partials/succes.html.twig */
class __TwigTemplate_09dd14979de9211521af9654b62bcf8f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "payment/partials/succes.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "payment/partials/succes.html.twig"));

        // line 1
        yield "
";
        // line 2
        yield from $this->unwrap()->yieldBlock('stylesheets', $context, $blocks);
        // line 56
        yield "
";
        // line 57
        yield from $this->unwrap()->yieldBlock('body', $context, $blocks);
        // line 94
        yield "



";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 2
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 3
        yield "<style>
    .confetti-canvas {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
    }

    .success-container {
        text-align: center;
        margin-top: 50px;
    }

    .success-container h1 {
        color: #28a745;
        font-size: 2.5rem;
    }

    .success-container p {
        font-size: 1.2rem;
    }

    .reservation-details {
        margin-top: 20px;
        padding: 20px;
        border: 1px solid #28a745;
        border-radius: 5px;
        background-color: #f8f9fa;
        display: inline-block;
        text-align: left;
    }

    .reservation-details h2 {
        color: #28a745;
        font-size: 1.5rem;
    }

    .reservation-details ul {
        list-style-type: none;
        padding: 0;
    }

    .reservation-details li {
        margin-bottom: 10px;
    }

    .home-button {
        margin-top: 20px;
    }
</style>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 57
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 58
        yield "<div class=\"success-container\">
    <h1>Paiement Réussi</h1>
    <p>Merci pour votre réservation. Votre paiement a été effectué avec succès.</p>

    <div class=\"reservation-details\">
        <h2>Détails de la réservation</h2>
        <ul>
            <li><strong>Check-in Date:</strong> ";
        // line 65
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["check_in_date"]) || array_key_exists("check_in_date", $context) ? $context["check_in_date"] : (function () { throw new RuntimeError('Variable "check_in_date" does not exist.', 65, $this->source); })()), "html", null, true);
        yield "</li>
            <li><strong>Check-out Date:</strong> ";
        // line 66
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["check_out_date"]) || array_key_exists("check_out_date", $context) ? $context["check_out_date"] : (function () { throw new RuntimeError('Variable "check_out_date" does not exist.', 66, $this->source); })()), "html", null, true);
        yield "</li>
            <li><strong>Logement:</strong> ";
        // line 67
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["logement_type"]) || array_key_exists("logement_type", $context) ? $context["logement_type"] : (function () { throw new RuntimeError('Variable "logement_type" does not exist.', 67, $this->source); })()), "html", null, true);
        yield "</li>
            <li><strong>Total Price:</strong> ";
        // line 68
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["total_price"]) || array_key_exists("total_price", $context) ? $context["total_price"] : (function () { throw new RuntimeError('Variable "total_price" does not exist.', 68, $this->source); })()), "html", null, true);
        yield "€</li>
        </ul>
    </div>

    <div class=\"home-button\">
        <a href=\"";
        // line 73
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_home");
        yield "\" class=\"btn btn-primary\">Retour à l'accueil</a>
    </div>
</div>

<canvas class=\"confetti-canvas\" id=\"confetti-canvas\"></canvas>

";
        // line 79
        yield from $this->unwrap()->yieldBlock('javascripts', $context, $blocks);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 80
        yield "<script src=\"https://cdn.jsdelivr.net/npm/canvas-confetti@1.4.0/dist/confetti.browser.min.js\"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var confettiSettings = { target: 'confetti-canvas' };
        var confetti = new ConfettiGenerator(confettiSettings);
        confetti.render();

        setTimeout(function() {
            confetti.clear();
        }, 5000);
    });
</script>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "payment/partials/succes.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  213 => 80,  193 => 79,  184 => 73,  176 => 68,  172 => 67,  168 => 66,  164 => 65,  155 => 58,  145 => 57,  82 => 3,  72 => 2,  57 => 94,  55 => 57,  52 => 56,  50 => 2,  47 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("
{% block stylesheets %}
<style>
    .confetti-canvas {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
    }

    .success-container {
        text-align: center;
        margin-top: 50px;
    }

    .success-container h1 {
        color: #28a745;
        font-size: 2.5rem;
    }

    .success-container p {
        font-size: 1.2rem;
    }

    .reservation-details {
        margin-top: 20px;
        padding: 20px;
        border: 1px solid #28a745;
        border-radius: 5px;
        background-color: #f8f9fa;
        display: inline-block;
        text-align: left;
    }

    .reservation-details h2 {
        color: #28a745;
        font-size: 1.5rem;
    }

    .reservation-details ul {
        list-style-type: none;
        padding: 0;
    }

    .reservation-details li {
        margin-bottom: 10px;
    }

    .home-button {
        margin-top: 20px;
    }
</style>
{% endblock %}

{% block body %}
<div class=\"success-container\">
    <h1>Paiement Réussi</h1>
    <p>Merci pour votre réservation. Votre paiement a été effectué avec succès.</p>

    <div class=\"reservation-details\">
        <h2>Détails de la réservation</h2>
        <ul>
            <li><strong>Check-in Date:</strong> {{ check_in_date }}</li>
            <li><strong>Check-out Date:</strong> {{ check_out_date }}</li>
            <li><strong>Logement:</strong> {{ logement_type }}</li>
            <li><strong>Total Price:</strong> {{ total_price }}€</li>
        </ul>
    </div>

    <div class=\"home-button\">
        <a href=\"{{ path('app_home') }}\" class=\"btn btn-primary\">Retour à l'accueil</a>
    </div>
</div>

<canvas class=\"confetti-canvas\" id=\"confetti-canvas\"></canvas>

{% block javascripts %}
<script src=\"https://cdn.jsdelivr.net/npm/canvas-confetti@1.4.0/dist/confetti.browser.min.js\"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var confettiSettings = { target: 'confetti-canvas' };
        var confetti = new ConfettiGenerator(confettiSettings);
        confetti.render();

        setTimeout(function() {
            confetti.clear();
        }, 5000);
    });
</script>
{% endblock %}
{% endblock %}




", "payment/partials/succes.html.twig", "/home/formatpro/Bureau/Camping Serenity/Camping/templates/payment/partials/succes.html.twig");
    }
}
