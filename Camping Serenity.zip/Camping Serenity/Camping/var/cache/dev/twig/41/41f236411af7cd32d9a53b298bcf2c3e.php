<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* layouts/partials/_about_section.html.twig */
class __TwigTemplate_fede9c75adac37adc9acadc8736a284d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "layouts/partials/_about_section.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "layouts/partials/_about_section.html.twig"));

        yield "<section id=\"about\" class=\"about\">
      <div class=\"container\">

        <div class=\"row justify-content-end\">
          <div class=\"col-lg-11\">
            <div class=\"row justify-content-end\">

              <div class=\"col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch\">
                <div class=\"count-box py-5\">
                  <i class=\"bi bi-emoji-smile\"></i>
                  <span data-purecounter-start=\"0\" data-purecounter-end=\"65\" class=\"purecounter\">0</span>
                  <p>Happy Clients</p>
                </div>
              </div>

              <div class=\"col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch\">
                <div class=\"count-box py-5\">
                  <i class=\"bi bi-journal-richtext\"></i>
                  <span data-purecounter-start=\"0\" data-purecounter-end=\"85\" class=\"purecounter\">0</span>
                  <p>Projects</p>
                </div>
              </div>

              <div class=\"col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch\">
                <div class=\"count-box pb-5 pt-0 pt-lg-5\">
                  <i class=\"bi bi-clock\"></i>
                  <span data-purecounter-start=\"0\" data-purecounter-end=\"27\" class=\"purecounter\">0</span>
                  <p>Years of experience</p>
                </div>
              </div>

              <div class=\"col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch\">
                <div class=\"count-box pb-5 pt-0 pt-lg-5\">
                  <i class=\"bi bi-award\"></i>
                  <span data-purecounter-start=\"0\" data-purecounter-end=\"22\" class=\"purecounter\">0</span>
                  <p>Awards</p>
                </div>
              </div>

            </div>
          </div>
        </div>

        <div class=\"row\">

          <div class=\"col-lg-6 video-box align-self-baseline position-relative\">
            <img src=\"assets/img/about.jpg\" class=\"img-fluid\" alt=\"\">
            <a href=\"https://www.youtube.com/watch?v=bKSG0zQq1wY\" class=\"glightbox play-btn mb-4\"></a>
          </div>

          <div class=\"col-lg-6 pt-3 pt-lg-0 content\">
            <h3>Bienvenue au Super Camping d'Argelès-sur-Mer || Un Écrin de Nature Entre Mer et Montagne .</h3>
            <p class=\"fst-italic\">
              

              Des Hébergements Confortables
              Nous vous proposons une large gamme d'hébergements pour répondre à tous vos besoins :

              Mobil-homes modernes et tout équipés : Profitez du confort comme à la maison avec nos mobil-homes spacieux, climatisés et dotés de terrasses privées.
              
            </p>
            <ul>
              <li><i class=\"bx bx-check-double\"></i> Parc aquatique : Toboggans, piscines chauffées et pataugeoires pour le plaisir des petits et des grands.</li>
              <li><i class=\"bx bx-check-double\"></i> Animations et spectacles : Des animations en journée et des spectacles en soirée pour divertir toute la famille.</li>
              <li><i class=\"bx bx-check-double\"></i> Clubs enfants et ados : Des activités encadrées pour que chacun s’amuse selon son âge et ses envies.</li>
              <li><i class=\"bx bx-check-double\"></i> Sports et loisirs : Terrains de sport, salle de fitness, et activités nautiques pour les plus sportifs.</li>
            </ul>
            <p>
              Réservez Votre Séjour
              Ne manquez pas l’occasion de passer des vacances inoubliables au Super Camping d'Argelès-sur-Mer. Réservez dès maintenant et préparez-vous à vivre des moments magiques dans un cadre exceptionnel.
              Nous avons hâte de vous accueillir et de partager avec vous la beauté et la sérénité d'Argelès-sur-Mer. À très bientôt !
            </p>
          </div>

        </div>

      </div>
    </section>";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "layouts/partials/_about_section.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Source("<section id=\"about\" class=\"about\">
      <div class=\"container\">

        <div class=\"row justify-content-end\">
          <div class=\"col-lg-11\">
            <div class=\"row justify-content-end\">

              <div class=\"col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch\">
                <div class=\"count-box py-5\">
                  <i class=\"bi bi-emoji-smile\"></i>
                  <span data-purecounter-start=\"0\" data-purecounter-end=\"65\" class=\"purecounter\">0</span>
                  <p>Happy Clients</p>
                </div>
              </div>

              <div class=\"col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch\">
                <div class=\"count-box py-5\">
                  <i class=\"bi bi-journal-richtext\"></i>
                  <span data-purecounter-start=\"0\" data-purecounter-end=\"85\" class=\"purecounter\">0</span>
                  <p>Projects</p>
                </div>
              </div>

              <div class=\"col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch\">
                <div class=\"count-box pb-5 pt-0 pt-lg-5\">
                  <i class=\"bi bi-clock\"></i>
                  <span data-purecounter-start=\"0\" data-purecounter-end=\"27\" class=\"purecounter\">0</span>
                  <p>Years of experience</p>
                </div>
              </div>

              <div class=\"col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch\">
                <div class=\"count-box pb-5 pt-0 pt-lg-5\">
                  <i class=\"bi bi-award\"></i>
                  <span data-purecounter-start=\"0\" data-purecounter-end=\"22\" class=\"purecounter\">0</span>
                  <p>Awards</p>
                </div>
              </div>

            </div>
          </div>
        </div>

        <div class=\"row\">

          <div class=\"col-lg-6 video-box align-self-baseline position-relative\">
            <img src=\"assets/img/about.jpg\" class=\"img-fluid\" alt=\"\">
            <a href=\"https://www.youtube.com/watch?v=bKSG0zQq1wY\" class=\"glightbox play-btn mb-4\"></a>
          </div>

          <div class=\"col-lg-6 pt-3 pt-lg-0 content\">
            <h3>Bienvenue au Super Camping d'Argelès-sur-Mer || Un Écrin de Nature Entre Mer et Montagne .</h3>
            <p class=\"fst-italic\">
              

              Des Hébergements Confortables
              Nous vous proposons une large gamme d'hébergements pour répondre à tous vos besoins :

              Mobil-homes modernes et tout équipés : Profitez du confort comme à la maison avec nos mobil-homes spacieux, climatisés et dotés de terrasses privées.
              
            </p>
            <ul>
              <li><i class=\"bx bx-check-double\"></i> Parc aquatique : Toboggans, piscines chauffées et pataugeoires pour le plaisir des petits et des grands.</li>
              <li><i class=\"bx bx-check-double\"></i> Animations et spectacles : Des animations en journée et des spectacles en soirée pour divertir toute la famille.</li>
              <li><i class=\"bx bx-check-double\"></i> Clubs enfants et ados : Des activités encadrées pour que chacun s’amuse selon son âge et ses envies.</li>
              <li><i class=\"bx bx-check-double\"></i> Sports et loisirs : Terrains de sport, salle de fitness, et activités nautiques pour les plus sportifs.</li>
            </ul>
            <p>
              Réservez Votre Séjour
              Ne manquez pas l’occasion de passer des vacances inoubliables au Super Camping d'Argelès-sur-Mer. Réservez dès maintenant et préparez-vous à vivre des moments magiques dans un cadre exceptionnel.
              Nous avons hâte de vous accueillir et de partager avec vous la beauté et la sérénité d'Argelès-sur-Mer. À très bientôt !
            </p>
          </div>

        </div>

      </div>
    </section>", "layouts/partials/_about_section.html.twig", "/home/formatpro/Bureau/Camping Serenity/Camping/templates/layouts/partials/_about_section.html.twig");
    }
}
