<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* layouts/partials/_end_services.html.twig */
class __TwigTemplate_19c70c2e8ddd30f8617e1956699d204c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "layouts/partials/_end_services.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "layouts/partials/_end_services.html.twig"));

        yield "<style>
  .icon-box {
    padding: 30px; /* Increase padding */
    border: 1px solid #ddd; /* Optional: Add border for visibility */
    margin-bottom: 20px; /* Increase space between boxes */
    border-radius: 10px; /* Optional: Add rounded corners */
  }

  .icon-box .icon {
    font-size: 48px; /* Increase icon size */
    margin-bottom: 10px; /* Space between icon and title */
  }

  .icon-box .title {
    font-size: 24px; /* Increase title size */
    margin-bottom: 15px; /* Space between title and description */
  }

  .icon-box .description {
    font-size: 18px; /* Increase description size */
  }
</style>

<section id=\"services\" class=\"services\">
  <div class=\"container\">
    <div class=\"section-title pt-5\" data-aos=\"fade-up\">
      <h2>Nos Services</h2>
    </div>

    <div class=\"row\">
      <div class=\"col-md-6\">
        <div class=\"icon-box\" data-aos=\"fade-up\">
          <div class=\"icon\"><i class=\"fa fa-utensils\" style=\"color: #ff689b;\"></i></div>
          <h4 class=\"title\"><a href=\"\">Services de Qualité</a></h4>
          <p class=\"description\">Restaurant et bar : Savourez les spécialités locales et des plats gourmands dans notre restaurant.
            Épicerie et boulangerie : Faites vos courses sur place et profitez de pains et viennoiseries frais chaque matin.
            Wi-Fi gratuit : Restez connecté avec notre connexion internet disponible dans tout le camping.</p>
        </div>
      </div>
      <div class=\"col-md-6\">
        <div class=\"icon-box\" data-aos=\"fade-up\">
          <div class=\"icon\"><i class=\"fa fa-map-marked-alt\" style=\"color: #e9bf06;\"></i></div>
          <h4 class=\"title\"><a href=\"\">Découverte de la Région</a></h4>
          <p class=\"description\">Argelès-sur-Mer est le point de départ idéal pour découvrir les trésors de la région :
            Les plages : Détendez-vous sur les plages de sable fin de la Méditerranée.
            Les montagnes : Partez en randonnée dans les Pyrénées pour des panoramas à couper le souffle.
            La culture : Explorez les villages pittoresques, les marchés locaux et les sites historiques.</p>
        </div>
      </div>

      <div class=\"col-md-6\" data-aos=\"fade-up\" data-aos-delay=\"100\">
        <div class=\"icon-box\">
          <div class=\"icon\"><i class=\"fa fa-swimmer\" style=\"color: #3fcdc7;\"></i></div>
          <h4 class=\"title\"><a href=\"\">Activités et Loisirs pour Tous</a></h4>
          <p class=\"description\">Parc aquatique : Toboggans, piscines chauffées et pataugeoires pour le plaisir des petits et des grands.
            Animations et spectacles : Des animations en journée et des spectacles en soirée pour divertir toute la famille.
            Clubs enfants et ados : Des activités encadrées pour que chacun s’amuse selon son âge et ses envies.
            Sports et loisirs : Terrains de sport, salle de fitness, et activités nautiques pour les plus sportifs.</p>
        </div>
      </div>
      <div class=\"col-md-6\" data-aos=\"fade-up\" data-aos-delay=\"100\">
        <div class=\"icon-box\">
          <div class=\"icon\"><i class=\"fa fa-bed\" style=\"color:#41cf2e;\"></i></div>
          <h4 class=\"title\"><a href=\"\">Des Hébergements Confortables</a></h4>
          <p class=\"description\">Mobil-homes modernes et tout équipés : Profitez du confort comme à la maison avec nos mobil-homes spacieux, climatisés et dotés de terrasses privées.
            Emplacements pour tentes et caravanes : Pour les amoureux de la nature, nos emplacements ombragés vous offriront tranquillité et convivialité.
            Chalets de luxe : Offrez-vous une expérience haut de gamme dans nos chalets luxueux avec vue imprenable sur la mer.</p>
        </div>
      </div>
    </div>
  </div>
</section>

";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "layouts/partials/_end_services.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Source("<style>
  .icon-box {
    padding: 30px; /* Increase padding */
    border: 1px solid #ddd; /* Optional: Add border for visibility */
    margin-bottom: 20px; /* Increase space between boxes */
    border-radius: 10px; /* Optional: Add rounded corners */
  }

  .icon-box .icon {
    font-size: 48px; /* Increase icon size */
    margin-bottom: 10px; /* Space between icon and title */
  }

  .icon-box .title {
    font-size: 24px; /* Increase title size */
    margin-bottom: 15px; /* Space between title and description */
  }

  .icon-box .description {
    font-size: 18px; /* Increase description size */
  }
</style>

<section id=\"services\" class=\"services\">
  <div class=\"container\">
    <div class=\"section-title pt-5\" data-aos=\"fade-up\">
      <h2>Nos Services</h2>
    </div>

    <div class=\"row\">
      <div class=\"col-md-6\">
        <div class=\"icon-box\" data-aos=\"fade-up\">
          <div class=\"icon\"><i class=\"fa fa-utensils\" style=\"color: #ff689b;\"></i></div>
          <h4 class=\"title\"><a href=\"\">Services de Qualité</a></h4>
          <p class=\"description\">Restaurant et bar : Savourez les spécialités locales et des plats gourmands dans notre restaurant.
            Épicerie et boulangerie : Faites vos courses sur place et profitez de pains et viennoiseries frais chaque matin.
            Wi-Fi gratuit : Restez connecté avec notre connexion internet disponible dans tout le camping.</p>
        </div>
      </div>
      <div class=\"col-md-6\">
        <div class=\"icon-box\" data-aos=\"fade-up\">
          <div class=\"icon\"><i class=\"fa fa-map-marked-alt\" style=\"color: #e9bf06;\"></i></div>
          <h4 class=\"title\"><a href=\"\">Découverte de la Région</a></h4>
          <p class=\"description\">Argelès-sur-Mer est le point de départ idéal pour découvrir les trésors de la région :
            Les plages : Détendez-vous sur les plages de sable fin de la Méditerranée.
            Les montagnes : Partez en randonnée dans les Pyrénées pour des panoramas à couper le souffle.
            La culture : Explorez les villages pittoresques, les marchés locaux et les sites historiques.</p>
        </div>
      </div>

      <div class=\"col-md-6\" data-aos=\"fade-up\" data-aos-delay=\"100\">
        <div class=\"icon-box\">
          <div class=\"icon\"><i class=\"fa fa-swimmer\" style=\"color: #3fcdc7;\"></i></div>
          <h4 class=\"title\"><a href=\"\">Activités et Loisirs pour Tous</a></h4>
          <p class=\"description\">Parc aquatique : Toboggans, piscines chauffées et pataugeoires pour le plaisir des petits et des grands.
            Animations et spectacles : Des animations en journée et des spectacles en soirée pour divertir toute la famille.
            Clubs enfants et ados : Des activités encadrées pour que chacun s’amuse selon son âge et ses envies.
            Sports et loisirs : Terrains de sport, salle de fitness, et activités nautiques pour les plus sportifs.</p>
        </div>
      </div>
      <div class=\"col-md-6\" data-aos=\"fade-up\" data-aos-delay=\"100\">
        <div class=\"icon-box\">
          <div class=\"icon\"><i class=\"fa fa-bed\" style=\"color:#41cf2e;\"></i></div>
          <h4 class=\"title\"><a href=\"\">Des Hébergements Confortables</a></h4>
          <p class=\"description\">Mobil-homes modernes et tout équipés : Profitez du confort comme à la maison avec nos mobil-homes spacieux, climatisés et dotés de terrasses privées.
            Emplacements pour tentes et caravanes : Pour les amoureux de la nature, nos emplacements ombragés vous offriront tranquillité et convivialité.
            Chalets de luxe : Offrez-vous une expérience haut de gamme dans nos chalets luxueux avec vue imprenable sur la mer.</p>
        </div>
      </div>
    </div>
  </div>
</section>

", "layouts/partials/_end_services.html.twig", "/home/formatpro/Bureau/Camping Serenity/Camping/templates/layouts/partials/_end_services.html.twig");
    }
}
