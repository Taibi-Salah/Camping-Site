<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* price/index.html.twig */
class __TwigTemplate_fc323c166b436453dcb0d5fa829b4078 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "price/index.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "price/index.html.twig"));

        // line 1
        yield "



";
        // line 5
        yield from $this->unwrap()->yieldBlock('stylesheets', $context, $blocks);
        // line 16
        yield "
";
        // line 17
        yield from $this->unwrap()->yieldBlock('body', $context, $blocks);
        // line 27
        yield "
";
        // line 28
        yield from $this->unwrap()->yieldBlock('javascripts', $context, $blocks);
        // line 42
        yield "

";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 5
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 6
        yield "        <link href=\"assets/vendor/aos/aos.css\" rel=\"stylesheet\">
    <link href=\"assets/vendor/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\">
    <link href=\"assets/vendor/bootstrap-icons/bootstrap-icons.css\" rel=\"stylesheet\">
    <link href=\"assets/vendor/boxicons/css/boxicons.min.css\" rel=\"stylesheet\">
    <link href=\"assets/vendor/glightbox/css/glightbox.min.css\" rel=\"stylesheet\">
    <link href=\"assets/vendor/swiper/swiper-bundle.min.css\" rel=\"stylesheet\">

     <link href=\"assets/css/style.css\" rel=\"stylesheet\">
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 17
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 18
        yield "

        
        ";
        // line 21
        yield Twig\Extension\CoreExtension::include($this->env, $context, "price/partials/breadcrumbs.html.twig");
        yield "
        ";
        // line 22
        yield Twig\Extension\CoreExtension::include($this->env, $context, "price/partials/pricing.html.twig");
        yield "
        ";
        // line 23
        yield Twig\Extension\CoreExtension::include($this->env, $context, "price/partials/faq.html.twig");
        yield "
        ";
        // line 24
        yield Twig\Extension\CoreExtension::include($this->env, $context, "price/partials/footer.html.twig");
        yield "
        
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 28
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 29
        yield "    
    <script src=\"assets/vendor/purecounter/purecounter_vanilla.js\"></script>
    <script src=\"assets/vendor/aos/aos.js\"></script>
    <script src=\"assets/vendor/bootstrap/js/bootstrap.bundle.min.js\"></script>
    <script src=\"assets/vendor/glightbox/js/glightbox.min.js\"></script>
    <script src=\"assets/vendor/isotope-layout/isotope.pkgd.min.js\"></script>
    <script src=\"assets/vendor/swiper/swiper-bundle.min.js\"></script>
    <script src=\"assets/vendor/waypoints/noframework.waypoints.js\"></script>
    <script src=\"assets/vendor/php-email-form/validate.js\"></script>

    <script src=\"assets/js/main.js\"></script>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "price/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  158 => 29,  148 => 28,  134 => 24,  130 => 23,  126 => 22,  122 => 21,  117 => 18,  107 => 17,  88 => 6,  78 => 5,  65 => 42,  63 => 28,  60 => 27,  58 => 17,  55 => 16,  53 => 5,  47 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("



{% block stylesheets %}
    {# Add any additional stylesheets specific to this page here #}
    <link href=\"assets/vendor/aos/aos.css\" rel=\"stylesheet\">
    <link href=\"assets/vendor/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\">
    <link href=\"assets/vendor/bootstrap-icons/bootstrap-icons.css\" rel=\"stylesheet\">
    <link href=\"assets/vendor/boxicons/css/boxicons.min.css\" rel=\"stylesheet\">
    <link href=\"assets/vendor/glightbox/css/glightbox.min.css\" rel=\"stylesheet\">
    <link href=\"assets/vendor/swiper/swiper-bundle.min.css\" rel=\"stylesheet\">

     <link href=\"assets/css/style.css\" rel=\"stylesheet\">
{% endblock %}

{% block body %}


        
        {{ include('price/partials/breadcrumbs.html.twig') }}
        {{ include('price/partials/pricing.html.twig') }}
        {{ include('price/partials/faq.html.twig') }}
        {{ include('price/partials/footer.html.twig') }}
        
{% endblock %}

{% block javascripts %}
    {# Add any additional JavaScript specific to this page here #}

    <script src=\"assets/vendor/purecounter/purecounter_vanilla.js\"></script>
    <script src=\"assets/vendor/aos/aos.js\"></script>
    <script src=\"assets/vendor/bootstrap/js/bootstrap.bundle.min.js\"></script>
    <script src=\"assets/vendor/glightbox/js/glightbox.min.js\"></script>
    <script src=\"assets/vendor/isotope-layout/isotope.pkgd.min.js\"></script>
    <script src=\"assets/vendor/swiper/swiper-bundle.min.js\"></script>
    <script src=\"assets/vendor/waypoints/noframework.waypoints.js\"></script>
    <script src=\"assets/vendor/php-email-form/validate.js\"></script>

    <script src=\"assets/js/main.js\"></script>
{% endblock %}


", "price/index.html.twig", "/home/formatpro/Bureau/Camping Serenity/Camping/templates/price/index.html.twig");
    }
}
