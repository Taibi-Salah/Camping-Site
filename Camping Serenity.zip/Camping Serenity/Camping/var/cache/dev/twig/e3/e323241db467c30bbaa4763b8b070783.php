<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* service/partials/feature.html.twig */
class __TwigTemplate_f5d7cf7f5f6e1a0326a983845acedca8 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "service/partials/feature.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "service/partials/feature.html.twig"));

        yield "<section id=\"features\" class=\"features\">
    <div class=\"container\">

        <div class=\"section-title\" data-aos=\"fade-up\">
            <h2>Nos Atouts</h2>
            <p>Découvrez ce qui rend notre camping unique et accueillant. Profitez de nos services et installations pour un séjour mémorable en pleine nature.</p>
        </div>

        <div class=\"row\">
            <div class=\"col-md-6 d-flex align-items-stretch\" data-aos=\"fade-up\">
                <div class=\"card\" style=\"background-image: url(assets/img/features-1.jpg);\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\"><a href=\"\">Cadre Naturel</a></h5>
                        <p class=\"card-text\">Plongez dans un environnement naturel exceptionnel, idéal pour se ressourcer et profiter de la tranquillité.</p>
                        <div class=\"read-more\"><a href=\"#\"><i class=\"bi bi-arrow-right\"></i> En Savoir Plus</a></div>
                    </div>
                </div>
            </div>
            <div class=\"col-md-6 d-flex align-items-stretch mt-4 mt-md-0\" data-aos=\"fade-up\">
                <div class=\"card\" style=\"background-image: url(assets/img/features-2.jpg);\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\"><a href=\"\">Services Complets</a></h5>
                        <p class=\"card-text\">Nous offrons des services de qualité incluant sanitaires modernes, Wi-Fi gratuit et zones de barbecue.</p>
                        <div class=\"read-more\"><a href=\"#\"><i class=\"bi bi-arrow-right\"></i> En Savoir Plus</a></div>
                    </div>
                </div>
            </div>
            <div class=\"col-md-6 d-flex align-items-stretch mt-4\" data-aos=\"fade-up\" data-aos-delay=\"100\">
                <div class=\"card\" style=\"background-image: url(assets/img/features-3.jpg);\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\"><a href=\"\">Activités de Loisirs</a></h5>
                        <p class=\"card-text\">Participez à une variété d'activités de loisirs, y compris les randonnées, les jeux en plein air, et bien plus encore.</p>
                        <div class=\"read-more\"><a href=\"#\"><i class=\"bi bi-arrow-right\"></i> En Savoir Plus</a></div>
                    </div>
                </div>
            </div>
            <div class=\"col-md-6 d-flex align-items-stretch mt-4\" data-aos=\"fade-up\" data-aos-delay=\"100\">
                <div class=\"card\" style=\"background-image: url(assets/img/features-4.jpg);\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\"><a href=\"\">Accueil Chaleureux</a></h5>
                        <p class=\"card-text\">Notre équipe vous accueille avec chaleur et professionnalisme pour un séjour confortable et agréable.</p>
                        <div class=\"read-more\"><a href=\"#\"><i class=\"bi bi-arrow-right\"></i> En Savoir Plus</a></div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "service/partials/feature.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Source("<section id=\"features\" class=\"features\">
    <div class=\"container\">

        <div class=\"section-title\" data-aos=\"fade-up\">
            <h2>Nos Atouts</h2>
            <p>Découvrez ce qui rend notre camping unique et accueillant. Profitez de nos services et installations pour un séjour mémorable en pleine nature.</p>
        </div>

        <div class=\"row\">
            <div class=\"col-md-6 d-flex align-items-stretch\" data-aos=\"fade-up\">
                <div class=\"card\" style=\"background-image: url(assets/img/features-1.jpg);\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\"><a href=\"\">Cadre Naturel</a></h5>
                        <p class=\"card-text\">Plongez dans un environnement naturel exceptionnel, idéal pour se ressourcer et profiter de la tranquillité.</p>
                        <div class=\"read-more\"><a href=\"#\"><i class=\"bi bi-arrow-right\"></i> En Savoir Plus</a></div>
                    </div>
                </div>
            </div>
            <div class=\"col-md-6 d-flex align-items-stretch mt-4 mt-md-0\" data-aos=\"fade-up\">
                <div class=\"card\" style=\"background-image: url(assets/img/features-2.jpg);\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\"><a href=\"\">Services Complets</a></h5>
                        <p class=\"card-text\">Nous offrons des services de qualité incluant sanitaires modernes, Wi-Fi gratuit et zones de barbecue.</p>
                        <div class=\"read-more\"><a href=\"#\"><i class=\"bi bi-arrow-right\"></i> En Savoir Plus</a></div>
                    </div>
                </div>
            </div>
            <div class=\"col-md-6 d-flex align-items-stretch mt-4\" data-aos=\"fade-up\" data-aos-delay=\"100\">
                <div class=\"card\" style=\"background-image: url(assets/img/features-3.jpg);\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\"><a href=\"\">Activités de Loisirs</a></h5>
                        <p class=\"card-text\">Participez à une variété d'activités de loisirs, y compris les randonnées, les jeux en plein air, et bien plus encore.</p>
                        <div class=\"read-more\"><a href=\"#\"><i class=\"bi bi-arrow-right\"></i> En Savoir Plus</a></div>
                    </div>
                </div>
            </div>
            <div class=\"col-md-6 d-flex align-items-stretch mt-4\" data-aos=\"fade-up\" data-aos-delay=\"100\">
                <div class=\"card\" style=\"background-image: url(assets/img/features-4.jpg);\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\"><a href=\"\">Accueil Chaleureux</a></h5>
                        <p class=\"card-text\">Notre équipe vous accueille avec chaleur et professionnalisme pour un séjour confortable et agréable.</p>
                        <div class=\"read-more\"><a href=\"#\"><i class=\"bi bi-arrow-right\"></i> En Savoir Plus</a></div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
", "service/partials/feature.html.twig", "/home/formatpro/Bureau/Camping Serenity/Camping/templates/service/partials/feature.html.twig");
    }
}
