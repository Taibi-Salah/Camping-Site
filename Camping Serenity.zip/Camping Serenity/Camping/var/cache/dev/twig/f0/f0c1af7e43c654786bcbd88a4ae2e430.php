<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* layouts/partials/_header.html.twig */
class __TwigTemplate_25ce7303e13491f5c0bfad84607a4f3f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "layouts/partials/_header.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "layouts/partials/_header.html.twig"));

        // line 1
        yield "<header id=\"header\" class=\"fixed-top d-flex align-items-center\">
    <div class=\"container d-flex align-items-center justify-content-between\">

      <div class=\"logo\">
        <h1 class=\"text-light\"><a href=\"";
        // line 5
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_home");
        yield "\">Serenity Camping  | * * * * * </a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href=\"index.html\"><img src=\"assets/img/logo.png\" alt=\"\" class=\"img-fluid\"></a>-->
      </div>

      <nav id=\"navbar\" class=\"navbar\">
        <ul>
          <li><a class=\"active\" href=\"";
        // line 12
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_home");
        yield "\">Acceuil</a></li>
          <li class=\"dropdown\"><a href=\"#\"><span>A Propos</span> <i class=\"bi bi-chevron-down\"></i></a>
            <ul>
              <li><a href=\"about.html\">A propos de nous</a></li>
              <li><a href=\"team.html\">Notre équipe</a></li>
              <li class=\"dropdown\"><a href=\"#\"><span>Nos Réseaux sociaux</span> <i class=\"bi bi-chevron-right\"></i></a>
                <ul>
                  <li><a href=\"#\">Instagram</a></li>
                  <li><a href=\"#\">Facebook</a></li>
                  <li><a href=\"#\">Tik Tok</a></li>
                </ul>
              </li>
            </ul>
          </li>
          <li><a href=\"";
        // line 26
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_service");
        yield "\">Services</a></li>
          <li><a href=\"";
        // line 27
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_price");
        yield "\">Tarifs</a></li>
          <li><a href=\"#\">Jeux & Animation </a></li>
          <li><a href=\"#\"></a></li>
          <li><a href=\"#\">Contact</a></li>

          <li><a class=\"getstarted\" href=\"";
        // line 32
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_price");
        yield "\">Reservez dés maintenant</a></li>
        </ul>
        <i class=\"bi bi-list mobile-nav-toggle\"></i>
      </nav><!-- .navbar -->

    </div>
  </header>";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "layouts/partials/_header.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  89 => 32,  81 => 27,  77 => 26,  60 => 12,  50 => 5,  44 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<header id=\"header\" class=\"fixed-top d-flex align-items-center\">
    <div class=\"container d-flex align-items-center justify-content-between\">

      <div class=\"logo\">
        <h1 class=\"text-light\"><a href=\"{{ path('app_home') }}\">Serenity Camping  | * * * * * </a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href=\"index.html\"><img src=\"assets/img/logo.png\" alt=\"\" class=\"img-fluid\"></a>-->
      </div>

      <nav id=\"navbar\" class=\"navbar\">
        <ul>
          <li><a class=\"active\" href=\"{{ path('app_home') }}\">Acceuil</a></li>
          <li class=\"dropdown\"><a href=\"#\"><span>A Propos</span> <i class=\"bi bi-chevron-down\"></i></a>
            <ul>
              <li><a href=\"about.html\">A propos de nous</a></li>
              <li><a href=\"team.html\">Notre équipe</a></li>
              <li class=\"dropdown\"><a href=\"#\"><span>Nos Réseaux sociaux</span> <i class=\"bi bi-chevron-right\"></i></a>
                <ul>
                  <li><a href=\"#\">Instagram</a></li>
                  <li><a href=\"#\">Facebook</a></li>
                  <li><a href=\"#\">Tik Tok</a></li>
                </ul>
              </li>
            </ul>
          </li>
          <li><a href=\"{{ path('app_service') }}\">Services</a></li>
          <li><a href=\"{{ path('app_price') }}\">Tarifs</a></li>
          <li><a href=\"#\">Jeux & Animation </a></li>
          <li><a href=\"#\"></a></li>
          <li><a href=\"#\">Contact</a></li>

          <li><a class=\"getstarted\" href=\"{{ path('app_price') }}\">Reservez dés maintenant</a></li>
        </ul>
        <i class=\"bi bi-list mobile-nav-toggle\"></i>
      </nav><!-- .navbar -->

    </div>
  </header>", "layouts/partials/_header.html.twig", "/home/formatpro/Bureau/Camping Serenity/Camping/templates/layouts/partials/_header.html.twig");
    }
}
