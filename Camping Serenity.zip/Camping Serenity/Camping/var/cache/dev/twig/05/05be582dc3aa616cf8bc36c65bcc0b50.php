<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* price/partials/breadcrumbs.html.twig */
class __TwigTemplate_f5e5224b61da3078d0a9ae986717752c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "price/partials/breadcrumbs.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "price/partials/breadcrumbs.html.twig"));

        // line 1
        yield "<section id=\"breadcrumbs\" class=\"breadcrumbs\">
      <div class=\"breadcrumb-hero\">
        <div class=\"container\">
          <div class=\"breadcrumb-hero\">
            <h2>Tarifs</h2>
            <p>Tarifs de Camping
Bienvenue à notre camping, où nous vous offrons une expérience inoubliable en pleine nature. Découvrez nos tarifs attractifs pour profiter d'un séjour agréable et reposant.. </p>
          </div>
        </div>
      </div>
      <div class=\"container\">
        <ol>
          <li><a href=\"";
        // line 13
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_home");
        yield "\">Acceuil</a></li>
          <li>Tarifs</li>
        </ol>
      </div>
    </section>";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "price/partials/breadcrumbs.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  58 => 13,  44 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<section id=\"breadcrumbs\" class=\"breadcrumbs\">
      <div class=\"breadcrumb-hero\">
        <div class=\"container\">
          <div class=\"breadcrumb-hero\">
            <h2>Tarifs</h2>
            <p>Tarifs de Camping
Bienvenue à notre camping, où nous vous offrons une expérience inoubliable en pleine nature. Découvrez nos tarifs attractifs pour profiter d'un séjour agréable et reposant.. </p>
          </div>
        </div>
      </div>
      <div class=\"container\">
        <ol>
          <li><a href=\"{{ path('app_home') }}\">Acceuil</a></li>
          <li>Tarifs</li>
        </ol>
      </div>
    </section>", "price/partials/breadcrumbs.html.twig", "/home/formatpro/Bureau/Camping Serenity/Camping/templates/price/partials/breadcrumbs.html.twig");
    }
}
