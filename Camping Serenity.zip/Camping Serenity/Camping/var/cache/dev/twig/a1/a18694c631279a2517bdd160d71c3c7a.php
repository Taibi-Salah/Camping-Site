<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* payment/partials/workprocess.html.twig */
class __TwigTemplate_46d5d246fad1954ee88b6ab3d4345626 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "payment/partials/workprocess.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "payment/partials/workprocess.html.twig"));

        yield "<section id=\"work-process\" class=\"work-process\">
    <div class=\"container\">

        <div class=\"section-title\" data-aos=\"fade-up\">
            <h2>Work Process</h2>
            <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
        </div>

        <div class=\"row content\">
            <div class=\"col-md-5\" data-aos=\"fade-right\">
                <img src=\"assets/img/work-process-1.png\" class=\"img-fluid\" alt=\"\">
            </div>
            <div class=\"col-md-7 pt-4\" data-aos=\"fade-left\">
                <h3>Voluptatem dignissimos provident quasi corporis voluptates sit assumenda.</h3>
                <p class=\"fst-italic\">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                    magna aliqua.
                </p>
                <ul>
                    <li><i class=\"bi bi-check\"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
                    <li><i class=\"bi bi-check\"></i> Duis aute irure dolor in reprehenderit in voluptate velit.</li>
                </ul>
            </div>
        </div>

    </div>
</section>

<!-- New Reservation Section -->
<section id=\"reservation\" class=\"reservation\">
    <div class=\"container\">

        <div class=\"section-title\" data-aos=\"fade-up\">
            <h2>Réservation</h2>
            <p>Sélectionnez vos dates de séjour et le type de logement. Le prix total sera calculé automatiquement.</p>
        </div>

        <div class=\"row content\">
            <div class=\"col-md-5\" data-aos=\"fade-right\">
            </div>
            <div class=\"col-md-7 pt-4\" data-aos=\"fade-left\">
                <h3>Sélectionnez vos dates de séjour</h3>
                <p class=\"fst-italic\">
                    Utilisez le calendrier ci-dessous pour choisir vos dates d'arrivée et de départ.
                </p>
                <div class=\"calendar-container\">
                    <input type=\"text\" id=\"date-range\" class=\"form-control\" placeholder=\"Sélectionner les dates\">
                </div>
                <div class=\"mt-3\">
                    <label for=\"accommodation\" class=\"form-label\">Type de logement</label>
                    <select id=\"accommodation\" class=\"form-control\">
                        <option value=\"tent\">Emplacement Tente - 20€/nuit</option>
                        <option value=\"caravan\">Emplacement Caravanes - 30€/nuit</option>
                        <option value=\"campervan\">Emplacement Camping-cars - 35€/nuit</option>
                    </select>
                </div>
                <div class=\"mt-3\">
                    <button class=\"btn btn-primary\" onclick=\"calculatePrice()\">Calculer le prix</button>
                </div>
                <div class=\"mt-3\" id=\"price-result\">
                    <!-- Price will be displayed here -->
                </div>
                <div class=\"mt-3\" id=\"payment-button\">
                    <!-- Payment button will be displayed here -->
                </div>
            </div>
        </div>

    </div>
</section>

<!-- Include necessary scripts for the calendar widget -->
<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css\">
<script src=\"https://cdn.jsdelivr.net/npm/flatpickr\"></script>
<script src=\"https://js.stripe.com/v3/\"></script>


<script>
    flatpickr(\"#date-range\", {
        mode: \"range\",
        minDate: \"today\",
        dateFormat: \"Y-m-d\",
    });

    const stripe = Stripe('pk_test_51PY4LwDzMg6ykNYFSJzY2WlgOVRoanXJC5JZUXAQ6rEcadmZJNUefi8vRfIPkm8GM9SqCbZmc7rH2CMePdtGW1sk00vtAJDkpG');

    async function calculatePrice() {
        console.log(\"Calculating price...\");
        const dateRange = document.getElementById('date-range').value;
        const accommodationType = document.getElementById('accommodation').value;

        if (!dateRange) {
            alert(\"Veuillez sélectionner les dates.\");
            return;
        }

        const dates = dateRange.split(' to ');
        if (dates.length !== 2) {
            alert(\"Veuillez sélectionner une plage de dates valide.\");
            return;
        }

        const startDate = new Date(dates[0]);
        const endDate = new Date(dates[1]);
        const nights = (endDate - startDate) / (1000 * 60 * 60 * 24);

        if (nights <= 0) {
            alert(\"La date de départ doit être ultérieure à la date d'arrivée.\");
            return;
        }

        let pricePerNight;
        switch (accommodationType) {
            case 'tent':
                pricePerNight = 20;
                break;
            case 'caravan':
                pricePerNight = 30;
                break;
            case 'campervan':
                pricePerNight = 35;
                break;
            default:
                pricePerNight = 0;
                break;
        }

        const totalPrice = pricePerNight * nights;

        document.getElementById('price-result').innerText = `Prix total pour \${nights} nuits : \${totalPrice}€`;

        // Create a payment button
        document.getElementById('payment-button').innerHTML = `<button class=\"btn btn-success mt-3\" onclick=\"redirectToStripe(\${totalPrice})\">Validez votre paiement ici</button>`;
    }

    async function redirectToStripe(totalPrice) {
    console.log(\"Redirecting to Stripe with totalPrice:\", totalPrice);
    const dateRange = document.getElementById('date-range').value;
    const accommodationType = document.getElementById('accommodation').value;
    const dates = dateRange.split(' to ');

    try {
        const response = await fetch('/create-checkout-session', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                price: totalPrice * 100, // Convert to cents
                check_in_date: dates[0],
                check_out_date: dates[1],
                logement_type: accommodationType
            }),
        });

        console.log(\"Raw response from server:\", response);

        if (response.ok) {
            const session = await response.json();
            console.log(\"Session created:\", session);

            // Redirect to Stripe Checkout
            const { error } = await stripe.redirectToCheckout({
                sessionId: session.id,
            });

            if (error) {
                console.error(\"Stripe checkout error:\", error);
                alert(\"An error occurred while redirecting to Stripe: \" + error.message);
            }
        } else {
            // Log error text for debugging
            const errorText = await response.text();
            console.error(\"Failed to create checkout session:\", errorText);
            alert(\"Failed to create checkout session: \" + errorText);
        }
    } catch (error) {
        console.error(\"Network or server error:\", error);
        alert(\"Network or server error: \" + error.message);
    }
}


</script>
";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "payment/partials/workprocess.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Source("<section id=\"work-process\" class=\"work-process\">
    <div class=\"container\">

        <div class=\"section-title\" data-aos=\"fade-up\">
            <h2>Work Process</h2>
            <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
        </div>

        <div class=\"row content\">
            <div class=\"col-md-5\" data-aos=\"fade-right\">
                <img src=\"assets/img/work-process-1.png\" class=\"img-fluid\" alt=\"\">
            </div>
            <div class=\"col-md-7 pt-4\" data-aos=\"fade-left\">
                <h3>Voluptatem dignissimos provident quasi corporis voluptates sit assumenda.</h3>
                <p class=\"fst-italic\">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                    magna aliqua.
                </p>
                <ul>
                    <li><i class=\"bi bi-check\"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
                    <li><i class=\"bi bi-check\"></i> Duis aute irure dolor in reprehenderit in voluptate velit.</li>
                </ul>
            </div>
        </div>

    </div>
</section>

<!-- New Reservation Section -->
<section id=\"reservation\" class=\"reservation\">
    <div class=\"container\">

        <div class=\"section-title\" data-aos=\"fade-up\">
            <h2>Réservation</h2>
            <p>Sélectionnez vos dates de séjour et le type de logement. Le prix total sera calculé automatiquement.</p>
        </div>

        <div class=\"row content\">
            <div class=\"col-md-5\" data-aos=\"fade-right\">
            </div>
            <div class=\"col-md-7 pt-4\" data-aos=\"fade-left\">
                <h3>Sélectionnez vos dates de séjour</h3>
                <p class=\"fst-italic\">
                    Utilisez le calendrier ci-dessous pour choisir vos dates d'arrivée et de départ.
                </p>
                <div class=\"calendar-container\">
                    <input type=\"text\" id=\"date-range\" class=\"form-control\" placeholder=\"Sélectionner les dates\">
                </div>
                <div class=\"mt-3\">
                    <label for=\"accommodation\" class=\"form-label\">Type de logement</label>
                    <select id=\"accommodation\" class=\"form-control\">
                        <option value=\"tent\">Emplacement Tente - 20€/nuit</option>
                        <option value=\"caravan\">Emplacement Caravanes - 30€/nuit</option>
                        <option value=\"campervan\">Emplacement Camping-cars - 35€/nuit</option>
                    </select>
                </div>
                <div class=\"mt-3\">
                    <button class=\"btn btn-primary\" onclick=\"calculatePrice()\">Calculer le prix</button>
                </div>
                <div class=\"mt-3\" id=\"price-result\">
                    <!-- Price will be displayed here -->
                </div>
                <div class=\"mt-3\" id=\"payment-button\">
                    <!-- Payment button will be displayed here -->
                </div>
            </div>
        </div>

    </div>
</section>

<!-- Include necessary scripts for the calendar widget -->
<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css\">
<script src=\"https://cdn.jsdelivr.net/npm/flatpickr\"></script>
<script src=\"https://js.stripe.com/v3/\"></script>


<script>
    flatpickr(\"#date-range\", {
        mode: \"range\",
        minDate: \"today\",
        dateFormat: \"Y-m-d\",
    });

    const stripe = Stripe('pk_test_51PY4LwDzMg6ykNYFSJzY2WlgOVRoanXJC5JZUXAQ6rEcadmZJNUefi8vRfIPkm8GM9SqCbZmc7rH2CMePdtGW1sk00vtAJDkpG');

    async function calculatePrice() {
        console.log(\"Calculating price...\");
        const dateRange = document.getElementById('date-range').value;
        const accommodationType = document.getElementById('accommodation').value;

        if (!dateRange) {
            alert(\"Veuillez sélectionner les dates.\");
            return;
        }

        const dates = dateRange.split(' to ');
        if (dates.length !== 2) {
            alert(\"Veuillez sélectionner une plage de dates valide.\");
            return;
        }

        const startDate = new Date(dates[0]);
        const endDate = new Date(dates[1]);
        const nights = (endDate - startDate) / (1000 * 60 * 60 * 24);

        if (nights <= 0) {
            alert(\"La date de départ doit être ultérieure à la date d'arrivée.\");
            return;
        }

        let pricePerNight;
        switch (accommodationType) {
            case 'tent':
                pricePerNight = 20;
                break;
            case 'caravan':
                pricePerNight = 30;
                break;
            case 'campervan':
                pricePerNight = 35;
                break;
            default:
                pricePerNight = 0;
                break;
        }

        const totalPrice = pricePerNight * nights;

        document.getElementById('price-result').innerText = `Prix total pour \${nights} nuits : \${totalPrice}€`;

        // Create a payment button
        document.getElementById('payment-button').innerHTML = `<button class=\"btn btn-success mt-3\" onclick=\"redirectToStripe(\${totalPrice})\">Validez votre paiement ici</button>`;
    }

    async function redirectToStripe(totalPrice) {
    console.log(\"Redirecting to Stripe with totalPrice:\", totalPrice);
    const dateRange = document.getElementById('date-range').value;
    const accommodationType = document.getElementById('accommodation').value;
    const dates = dateRange.split(' to ');

    try {
        const response = await fetch('/create-checkout-session', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                price: totalPrice * 100, // Convert to cents
                check_in_date: dates[0],
                check_out_date: dates[1],
                logement_type: accommodationType
            }),
        });

        console.log(\"Raw response from server:\", response);

        if (response.ok) {
            const session = await response.json();
            console.log(\"Session created:\", session);

            // Redirect to Stripe Checkout
            const { error } = await stripe.redirectToCheckout({
                sessionId: session.id,
            });

            if (error) {
                console.error(\"Stripe checkout error:\", error);
                alert(\"An error occurred while redirecting to Stripe: \" + error.message);
            }
        } else {
            // Log error text for debugging
            const errorText = await response.text();
            console.error(\"Failed to create checkout session:\", errorText);
            alert(\"Failed to create checkout session: \" + errorText);
        }
    } catch (error) {
        console.error(\"Network or server error:\", error);
        alert(\"Network or server error: \" + error.message);
    }
}


</script>
", "payment/partials/workprocess.html.twig", "/home/formatpro/Bureau/Camping Serenity/Camping/templates/payment/partials/workprocess.html.twig");
    }
}
