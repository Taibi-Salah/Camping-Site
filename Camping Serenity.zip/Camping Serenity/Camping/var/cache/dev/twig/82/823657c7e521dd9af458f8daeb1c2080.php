<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* price/partials/pricing.html.twig */
class __TwigTemplate_ae5a5b9ad986df5aa3dc319e511ddbcf extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "price/partials/pricing.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "price/partials/pricing.html.twig"));

        // line 1
        yield "<section id=\"pricing\" class=\"pricing\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-lg-4 col-md-6\">
                    <div class=\"box\" data-aos=\"fade-up\">
                        <h3>Emplacements Tente</h3>
                        <img src=\"";
        // line 7
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/tente.jpg"), "html", null, true);
        yield "\" alt=\"Emplacement Tente\" class=\"img-fluid\">
                        <h4>20€<span> / nuit</span></h4>
                        <ul>
                            <li>Accès aux sanitaires</li>
                            <li>Wi-Fi gratuit</li>
                            <li>Zone de barbecue</li>
                            <li class=\"na\">Électricité non incluse</li>
                        </ul>
                        <div class=\"btn-wrap\">
                            <a href=\"";
        // line 16
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_payment");
        yield "\" class=\"btn-buy\">Réserver</a>
                        </div>
                    </div>
                </div>

                <div class=\"col-lg-4 col-md-6 mt-4 mt-md-0\">
                    <div class=\"box featured\" data-aos=\"fade-up\" data-aos-delay=\"100\">
                        <h3>Emplacements Caravanes</h3>
                        <img src=\"";
        // line 24
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/caravane.jpg"), "html", null, true);
        yield "\" alt=\"Emplacement Caravanes\" class=\"img-fluid\">
                        <h4>30€<span> / nuit</span></h4>
                        <ul>
                            <li>Accès aux sanitaires</li>
                            <li>Wi-Fi gratuit</li>
                            <li>Électricité incluse</li>
                            <li>Zone de barbecue</li>
                        </ul>
                        <div class=\"btn-wrap\">
                            <a href=\"";
        // line 33
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_payment");
        yield "\" class=\"btn-buy\">Réserver</a>
                        </div>
                    </div>
                </div>

                <div class=\"col-lg-4 col-md-6 mt-4 mt-lg-0\">
                    <div class=\"box\" data-aos=\"fade-up\" data-aos-delay=\"200\">
                        <h3>Emplacement Camping-cars</h3>
                        <img src=\"";
        // line 41
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/campingcar.jpg"), "html", null, true);
        yield "\" alt=\"Emplacement Camping-cars\" class=\"img-fluid\">
                        <h4>35€<span> / nuit</span></h4>
                        <ul>
                            <li>Accès aux sanitaires</li>
                            <li>Wi-Fi gratuit</li>
                            <li>Électricité incluse</li>
                            <li>Zone de barbecue</li>
                        </ul>
                        <div class=\"btn-wrap\">
                            <a href=\"";
        // line 50
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_payment");
        yield "\" class=\"btn-buy\">Réserver</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "price/partials/pricing.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  110 => 50,  98 => 41,  87 => 33,  75 => 24,  64 => 16,  52 => 7,  44 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<section id=\"pricing\" class=\"pricing\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-lg-4 col-md-6\">
                    <div class=\"box\" data-aos=\"fade-up\">
                        <h3>Emplacements Tente</h3>
                        <img src=\"{{ asset('assets/img/tente.jpg') }}\" alt=\"Emplacement Tente\" class=\"img-fluid\">
                        <h4>20€<span> / nuit</span></h4>
                        <ul>
                            <li>Accès aux sanitaires</li>
                            <li>Wi-Fi gratuit</li>
                            <li>Zone de barbecue</li>
                            <li class=\"na\">Électricité non incluse</li>
                        </ul>
                        <div class=\"btn-wrap\">
                            <a href=\"{{ path('app_payment') }}\" class=\"btn-buy\">Réserver</a>
                        </div>
                    </div>
                </div>

                <div class=\"col-lg-4 col-md-6 mt-4 mt-md-0\">
                    <div class=\"box featured\" data-aos=\"fade-up\" data-aos-delay=\"100\">
                        <h3>Emplacements Caravanes</h3>
                        <img src=\"{{ asset('assets/img/caravane.jpg') }}\" alt=\"Emplacement Caravanes\" class=\"img-fluid\">
                        <h4>30€<span> / nuit</span></h4>
                        <ul>
                            <li>Accès aux sanitaires</li>
                            <li>Wi-Fi gratuit</li>
                            <li>Électricité incluse</li>
                            <li>Zone de barbecue</li>
                        </ul>
                        <div class=\"btn-wrap\">
                            <a href=\"{{ path('app_payment') }}\" class=\"btn-buy\">Réserver</a>
                        </div>
                    </div>
                </div>

                <div class=\"col-lg-4 col-md-6 mt-4 mt-lg-0\">
                    <div class=\"box\" data-aos=\"fade-up\" data-aos-delay=\"200\">
                        <h3>Emplacement Camping-cars</h3>
                        <img src=\"{{ asset('assets/img/campingcar.jpg') }}\" alt=\"Emplacement Camping-cars\" class=\"img-fluid\">
                        <h4>35€<span> / nuit</span></h4>
                        <ul>
                            <li>Accès aux sanitaires</li>
                            <li>Wi-Fi gratuit</li>
                            <li>Électricité incluse</li>
                            <li>Zone de barbecue</li>
                        </ul>
                        <div class=\"btn-wrap\">
                            <a href=\"{{ path('app_payment') }}\" class=\"btn-buy\">Réserver</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
", "price/partials/pricing.html.twig", "/home/formatpro/Bureau/Camping Serenity/Camping/templates/price/partials/pricing.html.twig");
    }
}
