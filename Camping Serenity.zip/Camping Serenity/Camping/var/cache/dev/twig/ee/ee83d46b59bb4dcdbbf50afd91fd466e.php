<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* service/partials/service.html.twig */
class __TwigTemplate_848f47412e7eca5f7c957aa726b85120 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "service/partials/service.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "service/partials/service.html.twig"));

        yield "<section id=\"services\" class=\"services\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-6\">
                <div class=\"icon-box\" data-aos=\"fade-up\">
                    <div class=\"icon\">
                        <i class=\"bi bi-tree\" style=\"font-size: 2rem; margin-left: 40px; color: #6c757d;\"></i>
                    </div>
                    <h4 class=\"title\" style=\"color: #6c757d;\"><a href=\"#\">Emplacements Tentes</a></h4>
                    <p class=\"description\">
                        Profitez de nos emplacements spacieux pour tentes avec accès aux sanitaires, Wi-Fi gratuit, et zone de barbecue.
                    </p>
                </div>
            </div>
            <div class=\"col-md-6\">
                <div class=\"icon-box\" data-aos=\"fade-up\">
                    <div class=\"icon\">
                        <i class=\"bi bi-house-door\" style=\"font-size: 2rem; margin-left: 40px; color: #17a2b8;\"></i>
                    </div>
                    <h4 class=\"title\" style=\"color: #17a2b8;\"><a href=\"#\">Emplacements Caravanes</a></h4>
                    <p class=\"description\">
                        Nos emplacements pour caravanes incluent l'électricité, l'accès aux sanitaires, et le Wi-Fi gratuit.
                    </p>
                </div>
            </div>
            <div class=\"col-md-6\" data-aos=\"fade-up\" data-aos-delay=\"100\">
                <div class=\"icon-box\">
                    <div class=\"icon\">
                        <i class=\"bi bi-activity\" style=\"font-size: 2rem; margin-left: 40px; color: #28a745;\"></i>
                    </div>
                    <h4 class=\"title\" style=\"color: #28a745;\"><a href=\"#\">Activités de Plein Air</a></h4>
                    <p class=\"description\">
                        Participez à nos nombreuses activités de plein air, y compris les randonnées, le volley-ball et les aires de jeux pour enfants.
                    </p>
                </div>
            </div>
            <div class=\"col-md-6\" data-aos=\"fade-up\" data-aos-delay=\"100\">
                <div class=\"icon-box\">
                    <div class=\"icon\">
                        <i class=\"bi bi-wifi\" style=\"font-size: 2rem; margin-left: 40px; color: #ffc107;\"></i>
                    </div>
                    <h4 class=\"title\" style=\"color: #ffc107;\"><a href=\"#\">Wi-Fi Gratuit</a></h4>
                    <p class=\"description\">
                        Restez connecté avec notre service Wi-Fi gratuit disponible dans tout le camping.
                    </p>
                </div>
            </div>
            <div class=\"col-md-6\" data-aos=\"fade-up\" data-aos-delay=\"200\">
                <div class=\"icon-box\">
                    <div class=\"icon\">
                        <i class=\"bi bi-heart\" style=\"font-size: 2rem; margin-left: 40px; color: #fd7e14;\"></i>
                    </div>
                    <h4 class=\"title\" style=\"color: #fd7e14;\"><a href=\"#\">Animaux de Compagnie Bienvenus</a></h4>
                    <p class=\"description\">
                        Nous accueillons vos animaux de compagnie. Assurez-vous qu'ils soient tenus en laisse et respectent les autres campeurs.
                    </p>
                </div>
            </div>
            <div class=\"col-md-6\" data-aos=\"fade-up\" data-aos-delay=\"200\">
                <div class=\"icon-box\">
                    <div class=\"icon\">
                        <i class=\"bi bi-calendar-check\" style=\"font-size: 2rem; margin-left: 40px; color: #dc3545;\"></i>
                    </div>
                    <h4 class=\"title\" style=\"color: #dc3545;\"><a href=\"#\">Réservation Facile</a></h4>
                    <p class=\"description\">
                        Réservez votre emplacement en toute simplicité avec notre système de réservation en ligne.
                        <button id=\"checkout-button\" class=\"btn btn-success mt-3\">Validez votre paiement ici</button>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Include necessary scripts for Stripe -->
<script src=\"https://js.stripe.com/v3/\"></script>
<script>
    const stripe = Stripe('your_stripe_publishable_key');

    document.getElementById('checkout-button').addEventListener('click', async () => {
        const response = await fetch('/create-checkout-session', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
        });

        const session = await response.json();

        // Redirect to Stripe Checkout
        const { error } = await stripe.redirectToCheckout({
            sessionId: session.id,
        });

        if (error) {
            console.error(error);
        }
    });
</script>








";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "service/partials/service.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Source("<section id=\"services\" class=\"services\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-6\">
                <div class=\"icon-box\" data-aos=\"fade-up\">
                    <div class=\"icon\">
                        <i class=\"bi bi-tree\" style=\"font-size: 2rem; margin-left: 40px; color: #6c757d;\"></i>
                    </div>
                    <h4 class=\"title\" style=\"color: #6c757d;\"><a href=\"#\">Emplacements Tentes</a></h4>
                    <p class=\"description\">
                        Profitez de nos emplacements spacieux pour tentes avec accès aux sanitaires, Wi-Fi gratuit, et zone de barbecue.
                    </p>
                </div>
            </div>
            <div class=\"col-md-6\">
                <div class=\"icon-box\" data-aos=\"fade-up\">
                    <div class=\"icon\">
                        <i class=\"bi bi-house-door\" style=\"font-size: 2rem; margin-left: 40px; color: #17a2b8;\"></i>
                    </div>
                    <h4 class=\"title\" style=\"color: #17a2b8;\"><a href=\"#\">Emplacements Caravanes</a></h4>
                    <p class=\"description\">
                        Nos emplacements pour caravanes incluent l'électricité, l'accès aux sanitaires, et le Wi-Fi gratuit.
                    </p>
                </div>
            </div>
            <div class=\"col-md-6\" data-aos=\"fade-up\" data-aos-delay=\"100\">
                <div class=\"icon-box\">
                    <div class=\"icon\">
                        <i class=\"bi bi-activity\" style=\"font-size: 2rem; margin-left: 40px; color: #28a745;\"></i>
                    </div>
                    <h4 class=\"title\" style=\"color: #28a745;\"><a href=\"#\">Activités de Plein Air</a></h4>
                    <p class=\"description\">
                        Participez à nos nombreuses activités de plein air, y compris les randonnées, le volley-ball et les aires de jeux pour enfants.
                    </p>
                </div>
            </div>
            <div class=\"col-md-6\" data-aos=\"fade-up\" data-aos-delay=\"100\">
                <div class=\"icon-box\">
                    <div class=\"icon\">
                        <i class=\"bi bi-wifi\" style=\"font-size: 2rem; margin-left: 40px; color: #ffc107;\"></i>
                    </div>
                    <h4 class=\"title\" style=\"color: #ffc107;\"><a href=\"#\">Wi-Fi Gratuit</a></h4>
                    <p class=\"description\">
                        Restez connecté avec notre service Wi-Fi gratuit disponible dans tout le camping.
                    </p>
                </div>
            </div>
            <div class=\"col-md-6\" data-aos=\"fade-up\" data-aos-delay=\"200\">
                <div class=\"icon-box\">
                    <div class=\"icon\">
                        <i class=\"bi bi-heart\" style=\"font-size: 2rem; margin-left: 40px; color: #fd7e14;\"></i>
                    </div>
                    <h4 class=\"title\" style=\"color: #fd7e14;\"><a href=\"#\">Animaux de Compagnie Bienvenus</a></h4>
                    <p class=\"description\">
                        Nous accueillons vos animaux de compagnie. Assurez-vous qu'ils soient tenus en laisse et respectent les autres campeurs.
                    </p>
                </div>
            </div>
            <div class=\"col-md-6\" data-aos=\"fade-up\" data-aos-delay=\"200\">
                <div class=\"icon-box\">
                    <div class=\"icon\">
                        <i class=\"bi bi-calendar-check\" style=\"font-size: 2rem; margin-left: 40px; color: #dc3545;\"></i>
                    </div>
                    <h4 class=\"title\" style=\"color: #dc3545;\"><a href=\"#\">Réservation Facile</a></h4>
                    <p class=\"description\">
                        Réservez votre emplacement en toute simplicité avec notre système de réservation en ligne.
                        <button id=\"checkout-button\" class=\"btn btn-success mt-3\">Validez votre paiement ici</button>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Include necessary scripts for Stripe -->
<script src=\"https://js.stripe.com/v3/\"></script>
<script>
    const stripe = Stripe('your_stripe_publishable_key');

    document.getElementById('checkout-button').addEventListener('click', async () => {
        const response = await fetch('/create-checkout-session', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
        });

        const session = await response.json();

        // Redirect to Stripe Checkout
        const { error } = await stripe.redirectToCheckout({
            sessionId: session.id,
        });

        if (error) {
            console.error(error);
        }
    });
</script>








", "service/partials/service.html.twig", "/home/formatpro/Bureau/Camping Serenity/Camping/templates/service/partials/service.html.twig");
    }
}
