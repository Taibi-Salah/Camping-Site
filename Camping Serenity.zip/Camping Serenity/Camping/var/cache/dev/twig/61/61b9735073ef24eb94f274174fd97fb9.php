<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* service/partials/breadcrumbs.html.twig */
class __TwigTemplate_056c348c8bad71557e93551799ff0f84 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "service/partials/breadcrumbs.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "service/partials/breadcrumbs.html.twig"));

        // line 1
        yield "<section id=\"breadcrumbs\" class=\"breadcrumbs\">
      <div class=\"breadcrumb-hero\">
        <div class=\"container\">
          <div class=\"breadcrumb-hero\">
            <h2>Services</h2>
            <p>
            Notre camping offre une expérience inoubliable en pleine nature, avec une variété de services pour rendre votre séjour confortable et agréable. Profitez de nos emplacements spacieux pour tentes, caravanes et camping-cars, tous équipés de l'accès aux sanitaires modernes et au Wi-Fi gratuit. Détendez-vous dans notre zone de barbecue et de pique-nique, idéale pour des repas en plein air en famille ou entre amis. Pour les amateurs de sports et d'activités de plein air, nous proposons des sentiers de randonnée pittoresques, des aires de jeux pour enfants, et des terrains pour le volley-ball et le badminton. Les animaux de compagnie sont également les bienvenus, sous réserve qu'ils soient tenus en laisse et que leurs maîtres veillent à la propreté des lieux. Réservez dès aujourd'hui pour découvrir la beauté et la tranquillité de notre camping.
            </p>

          </div>
        </div>
      </div>
      <div class=\"container\">
        <ol>
          <li><a href=\"";
        // line 15
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_home");
        yield "\">Acceuil</a></li>
          <li>Services</li>
        </ol>
      </div>
    </section>";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "service/partials/breadcrumbs.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  60 => 15,  44 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<section id=\"breadcrumbs\" class=\"breadcrumbs\">
      <div class=\"breadcrumb-hero\">
        <div class=\"container\">
          <div class=\"breadcrumb-hero\">
            <h2>Services</h2>
            <p>
            Notre camping offre une expérience inoubliable en pleine nature, avec une variété de services pour rendre votre séjour confortable et agréable. Profitez de nos emplacements spacieux pour tentes, caravanes et camping-cars, tous équipés de l'accès aux sanitaires modernes et au Wi-Fi gratuit. Détendez-vous dans notre zone de barbecue et de pique-nique, idéale pour des repas en plein air en famille ou entre amis. Pour les amateurs de sports et d'activités de plein air, nous proposons des sentiers de randonnée pittoresques, des aires de jeux pour enfants, et des terrains pour le volley-ball et le badminton. Les animaux de compagnie sont également les bienvenus, sous réserve qu'ils soient tenus en laisse et que leurs maîtres veillent à la propreté des lieux. Réservez dès aujourd'hui pour découvrir la beauté et la tranquillité de notre camping.
            </p>

          </div>
        </div>
      </div>
      <div class=\"container\">
        <ol>
          <li><a href=\"{{ path('app_home') }}\">Acceuil</a></li>
          <li>Services</li>
        </ol>
      </div>
    </section>", "service/partials/breadcrumbs.html.twig", "/home/formatpro/Bureau/Camping Serenity/Camping/templates/service/partials/breadcrumbs.html.twig");
    }
}
