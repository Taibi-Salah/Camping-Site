<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* payment/partials/skills.html.twig */
class __TwigTemplate_d60103cac8fdef999a42e9e55185a1b6 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "payment/partials/skills.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "payment/partials/skills.html.twig"));

        yield "<section id=\"skills\" class=\"skills section-bg\">
      <div class=\"container\">

        <div class=\"section-title\" data-aos=\"fade-up\">
          <h2>Our Skills</h2>
          <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
        </div>

        <div class=\"row\">
          <div class=\"col-lg-6\" data-aos=\"fade-right\">
            <img src=\"assets/img/skills-img.jpg\" class=\"img-fluid\" alt=\"\">
          </div>
          <div class=\"col-lg-6 pt-4 pt-lg-0 content\" data-aos=\"fade-left\">
            <h3>Voluptatem dignissimos provident quasi corporis voluptates</h3>
            <p class=\"fst-italic\">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
              magna aliqua.
            </p>
            <p>
              Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
              velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.
            </p>

            <div class=\"skills-content\">

              <div class=\"progress\">
                <span class=\"skill\">HTML <i class=\"val\">100%</i></span>
                <div class=\"progress-bar-wrap\">
                  <div class=\"progress-bar\" role=\"progressbar\" aria-valuenow=\"100\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>
                </div>
              </div>

              <div class=\"progress\">
                <span class=\"skill\">CSS <i class=\"val\">90%</i></span>
                <div class=\"progress-bar-wrap\">
                  <div class=\"progress-bar\" role=\"progressbar\" aria-valuenow=\"90\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>
                </div>
              </div>

              <div class=\"progress\">
                <span class=\"skill\">JavaScript <i class=\"val\">75%</i></span>
                <div class=\"progress-bar-wrap\">
                  <div class=\"progress-bar\" role=\"progressbar\" aria-valuenow=\"75\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>
                </div>
              </div>

              <div class=\"progress\">
                <span class=\"skill\">Photoshop <i class=\"val\">55%</i></span>
                <div class=\"progress-bar-wrap\">
                  <div class=\"progress-bar\" role=\"progressbar\" aria-valuenow=\"55\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>
                </div>
              </div>

            </div>

          </div>
        </div>

      </div>
    </section>";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "payment/partials/skills.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Source("<section id=\"skills\" class=\"skills section-bg\">
      <div class=\"container\">

        <div class=\"section-title\" data-aos=\"fade-up\">
          <h2>Our Skills</h2>
          <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
        </div>

        <div class=\"row\">
          <div class=\"col-lg-6\" data-aos=\"fade-right\">
            <img src=\"assets/img/skills-img.jpg\" class=\"img-fluid\" alt=\"\">
          </div>
          <div class=\"col-lg-6 pt-4 pt-lg-0 content\" data-aos=\"fade-left\">
            <h3>Voluptatem dignissimos provident quasi corporis voluptates</h3>
            <p class=\"fst-italic\">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
              magna aliqua.
            </p>
            <p>
              Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
              velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.
            </p>

            <div class=\"skills-content\">

              <div class=\"progress\">
                <span class=\"skill\">HTML <i class=\"val\">100%</i></span>
                <div class=\"progress-bar-wrap\">
                  <div class=\"progress-bar\" role=\"progressbar\" aria-valuenow=\"100\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>
                </div>
              </div>

              <div class=\"progress\">
                <span class=\"skill\">CSS <i class=\"val\">90%</i></span>
                <div class=\"progress-bar-wrap\">
                  <div class=\"progress-bar\" role=\"progressbar\" aria-valuenow=\"90\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>
                </div>
              </div>

              <div class=\"progress\">
                <span class=\"skill\">JavaScript <i class=\"val\">75%</i></span>
                <div class=\"progress-bar-wrap\">
                  <div class=\"progress-bar\" role=\"progressbar\" aria-valuenow=\"75\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>
                </div>
              </div>

              <div class=\"progress\">
                <span class=\"skill\">Photoshop <i class=\"val\">55%</i></span>
                <div class=\"progress-bar-wrap\">
                  <div class=\"progress-bar\" role=\"progressbar\" aria-valuenow=\"55\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>
                </div>
              </div>

            </div>

          </div>
        </div>

      </div>
    </section>", "payment/partials/skills.html.twig", "/home/formatpro/Bureau/Camping Serenity/Camping/templates/payment/partials/skills.html.twig");
    }
}
