<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* layouts/base.html.twig */
class __TwigTemplate_6ea043507c5a047ff6028b2b30d1a6af extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "layouts/base.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "layouts/base.html.twig"));

        // line 1
        yield "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"utf-8\">
        <meta content=\"width=device-width, initial-scale=1.0\" name=\"viewport\">
        <meta charset=\"UTF-8\">

        <title>Serenity Camping * * * * * </title>
        <meta content=\"\" name=\"description\">
        <meta content=\"\" name=\"keywords\">


        <title>";
        // line 13
        yield from $this->unwrap()->yieldBlock('title', $context, $blocks);
        yield "</title>

        ";
        // line 16
        yield "        <link href=\"assets/img/favicon.png\" rel=\"icon\">
        <link href=\"assets/img/apple-touch-icon.png\" rel=\"apple-touch-icon\">

        ";
        // line 20
        yield "        <link href=\"https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i\" rel=\"stylesheet\">
        
        
        
        ";
        // line 24
        yield from $this->unwrap()->yieldBlock('stylesheets', $context, $blocks);
        // line 44
        yield "
    </head>
    <body>


        ";
        // line 49
        yield Twig\Extension\CoreExtension::include($this->env, $context, "layouts/partials/_header.html.twig");
        yield "

        ";
        // line 51
        yield Twig\Extension\CoreExtension::include($this->env, $context, "layouts/partials/_hero.html.twig");
        yield "

        ";
        // line 53
        yield Twig\Extension\CoreExtension::include($this->env, $context, "layouts/partials/_about_section.html.twig");
        yield "

        ";
        // line 55
        yield Twig\Extension\CoreExtension::include($this->env, $context, "layouts/partials/_cta_section.html.twig");
        yield "

        ";
        // line 57
        yield Twig\Extension\CoreExtension::include($this->env, $context, "layouts/partials/_end_services.html.twig");
        yield "

        ";
        // line 59
        yield Twig\Extension\CoreExtension::include($this->env, $context, "layouts/partials/_footer.section.html.twig");
        yield "

        ";
        // line 61
        yield from $this->unwrap()->yieldBlock('body', $context, $blocks);
        // line 64
        yield "

        ";
        // line 66
        yield from $this->unwrap()->yieldBlock('javascripts', $context, $blocks);
        // line 84
        yield "

    </body>
</html>
";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 13
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        yield " Bienvenue chez Serenity Camping ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 24
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 25
        yield "            ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('encore_entry_link_tags')->getCallable()("app"), "html", null, true);
        yield "

            ";
        // line 28
        yield "
            <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css\">

            <link href=\"assets/vendor/aos/aos.css\" rel=\"stylesheet\">
            <link href=\"assets/vendor/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\">
            <link href=\"assets/vendor/bootstrap-icons/bootstrap-icons.css\" rel=\"stylesheet\">
            <link href=\"assets/vendor/boxicons/css/boxicons.min.css\" rel=\"stylesheet\">
            <link href=\"assets/vendor/glightbox/css/glightbox.min.css\" rel=\"stylesheet\">
            <link href=\"assets/vendor/swiper/swiper-bundle.min.css\" rel=\"stylesheet\">


            ";
        // line 40
        yield "            <link href=\"assets/css/style.css\" rel=\"stylesheet\">


        ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 61
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 62
        yield "        
        ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 66
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 67
        yield "            ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('encore_entry_script_tags')->getCallable()("app"), "html", null, true);
        yield "


            ";
        // line 70
        yield " 
            <script src=\"assets/vendor/purecounter/purecounter_vanilla.js\"></script>
            <script src=\"assets/vendor/aos/aos.js\"></script>
            <script src=\"assets/vendor/bootstrap/js/bootstrap.bundle.min.js\"></script>
            <script src=\"assets/vendor/glightbox/js/glightbox.min.js\"></script>
            <script src=\"assets/vendor/isotope-layout/isotope.pkgd.min.js\"></script>
            <script src=\"assets/vendor/swiper/swiper-bundle.min.js\"></script>
            <script src=\"assets/vendor/waypoints/noframework.waypoints.js\"></script>
            <script src=\"assets/vendor/php-email-form/validate.js\"></script>

            ";
        // line 81
        yield "            <script src=\"assets/js/main.js\"></script>
        
        ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "layouts/base.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  254 => 81,  242 => 70,  235 => 67,  225 => 66,  213 => 62,  203 => 61,  189 => 40,  176 => 28,  170 => 25,  160 => 24,  140 => 13,  125 => 84,  123 => 66,  119 => 64,  117 => 61,  112 => 59,  107 => 57,  102 => 55,  97 => 53,  92 => 51,  87 => 49,  80 => 44,  78 => 24,  72 => 20,  67 => 16,  62 => 13,  48 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"utf-8\">
        <meta content=\"width=device-width, initial-scale=1.0\" name=\"viewport\">
        <meta charset=\"UTF-8\">

        <title>Serenity Camping * * * * * </title>
        <meta content=\"\" name=\"description\">
        <meta content=\"\" name=\"keywords\">


        <title>{% block title %} Bienvenue chez Serenity Camping {% endblock %}</title>

        {# Favicons #}
        <link href=\"assets/img/favicon.png\" rel=\"icon\">
        <link href=\"assets/img/apple-touch-icon.png\" rel=\"apple-touch-icon\">

        {# Google Fonts #}
        <link href=\"https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i\" rel=\"stylesheet\">
        
        
        
        {% block stylesheets %}
            {{ encore_entry_link_tags('app') }}

            {# Vendor CSS Files #}

            <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css\">

            <link href=\"assets/vendor/aos/aos.css\" rel=\"stylesheet\">
            <link href=\"assets/vendor/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\">
            <link href=\"assets/vendor/bootstrap-icons/bootstrap-icons.css\" rel=\"stylesheet\">
            <link href=\"assets/vendor/boxicons/css/boxicons.min.css\" rel=\"stylesheet\">
            <link href=\"assets/vendor/glightbox/css/glightbox.min.css\" rel=\"stylesheet\">
            <link href=\"assets/vendor/swiper/swiper-bundle.min.css\" rel=\"stylesheet\">


            {# Template Main CSS File #}
            <link href=\"assets/css/style.css\" rel=\"stylesheet\">


        {% endblock %}

    </head>
    <body>


        {{ include('layouts/partials/_header.html.twig')}}

        {{ include('layouts/partials/_hero.html.twig')}}

        {{ include('layouts/partials/_about_section.html.twig')}}

        {{ include('layouts/partials/_cta_section.html.twig')}}

        {{ include('layouts/partials/_end_services.html.twig')}}

        {{ include('layouts/partials/_footer.section.html.twig')}}

        {% block body %}
        
        {% endblock %}


        {% block javascripts %}
            {{ encore_entry_script_tags('app') }}


            {# Vendor JS Files #} 
            <script src=\"assets/vendor/purecounter/purecounter_vanilla.js\"></script>
            <script src=\"assets/vendor/aos/aos.js\"></script>
            <script src=\"assets/vendor/bootstrap/js/bootstrap.bundle.min.js\"></script>
            <script src=\"assets/vendor/glightbox/js/glightbox.min.js\"></script>
            <script src=\"assets/vendor/isotope-layout/isotope.pkgd.min.js\"></script>
            <script src=\"assets/vendor/swiper/swiper-bundle.min.js\"></script>
            <script src=\"assets/vendor/waypoints/noframework.waypoints.js\"></script>
            <script src=\"assets/vendor/php-email-form/validate.js\"></script>

            {# Template Main JS File #}
            <script src=\"assets/js/main.js\"></script>
        
        {% endblock %}


    </body>
</html>
", "layouts/base.html.twig", "/home/formatpro/Bureau/Camping Serenity/Camping/templates/layouts/base.html.twig");
    }
}
