<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* payment/partials/footer.html.twig */
class __TwigTemplate_58fdfbd4ec0a3a73df0f4d2d62ea3af7 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "payment/partials/footer.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "payment/partials/footer.html.twig"));

        yield "<footer id=\"footer\">
    <div class=\"footer-top\">
      <div class=\"container\">
        <div class=\"row\">

          <div class=\"col-lg-3 col-md-6 footer-info\">
            <h3> Serenity Camping      || * * * * * </h3>
            <p>Venez découvrir pourquoi le Super Camping d'Argelès-sur-Mer est le choix préféré de tant de vacanciers. Réservez dès maintenant et préparez-vous à vivre des moments inoubliables dans un cadre exceptionnel. Nous avons hâte de vous accueillir et de partager avec vous la beauté et la sérénité de notre magnifique région.</p>
          </div>

          <div class=\"col-lg-3 col-md-6 footer-links\">
            <h4>Liens utiles</h4>
            <ul>
              <li><a href=\"#\">Acceuil</a></li>
              <li><a href=\"#\">A Propos</a></li>
              <li><a href=\"#\">Services</a></li>
              <li><a href=\"#\">Conditions d'utilisation</a></li>
              <li><a href=\"#\">Politique de confidentialité</a></li>
            </ul>
          </div>

          <div class=\"col-lg-3 col-md-6 footer-contact\">
            <h4>Contactez-nous</h4>
            <p>
              Super Camping d'Argelès-sur-Mer <br>
              Route de la Plage,66700 Argelès-sur-Mer,<br>
              France <br>
              <strong>Téléphone: </strong> +33 4 68 81 55 55<br>
              <strong>Email: </strong> contact@supercamping-argeles.com<br>
            </p>

            <div class=\"social-links\">
              <a href=\"#\" class=\"twitter\"><i class=\"bi bi-twitter\"></i></a>
              <a href=\"#\" class=\"facebook\"><i class=\"bi bi-facebook\"></i></a>
              <a href=\"#\" class=\"instagram\"><i class=\"bi bi-instagram\"></i></a>
              <a href=\"#\" class=\"linkedin\"><i class=\"bi bi-linkedin\"></i></a>
            </div>

          </div>

          <div class=\"col-lg-3 col-md-6 footer-newsletter\">
          <h4>Notre Newsletter</h4>
          <p>Restez informé des dernières nouveautés et offres spéciales de notre camping. Inscrivez-vous à notre newsletter pour recevoir des informations exclusives directement dans votre boîte mail.</p>
          <form action=\"\" method=\"post\">
            <input type=\"email\" name=\"email\" placeholder=\"Votre adresse email\"><input type=\"submit\" value=\"S'inscrire\">
          </form>
        </div>


        </div>
      </div>
    </div>

    <div class=\"container\">
    <div class=\"copyright\">
      &copy; Copyright <strong><span>Super Camping d'Argelès-sur-Mer</span></strong>. Tous droits réservés
    </div>
    <div class=\"credits\">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/serenity-bootstrap-corporate-template/ -->
    </div>
</div>

  </footer>";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "payment/partials/footer.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Source("<footer id=\"footer\">
    <div class=\"footer-top\">
      <div class=\"container\">
        <div class=\"row\">

          <div class=\"col-lg-3 col-md-6 footer-info\">
            <h3> Serenity Camping      || * * * * * </h3>
            <p>Venez découvrir pourquoi le Super Camping d'Argelès-sur-Mer est le choix préféré de tant de vacanciers. Réservez dès maintenant et préparez-vous à vivre des moments inoubliables dans un cadre exceptionnel. Nous avons hâte de vous accueillir et de partager avec vous la beauté et la sérénité de notre magnifique région.</p>
          </div>

          <div class=\"col-lg-3 col-md-6 footer-links\">
            <h4>Liens utiles</h4>
            <ul>
              <li><a href=\"#\">Acceuil</a></li>
              <li><a href=\"#\">A Propos</a></li>
              <li><a href=\"#\">Services</a></li>
              <li><a href=\"#\">Conditions d'utilisation</a></li>
              <li><a href=\"#\">Politique de confidentialité</a></li>
            </ul>
          </div>

          <div class=\"col-lg-3 col-md-6 footer-contact\">
            <h4>Contactez-nous</h4>
            <p>
              Super Camping d'Argelès-sur-Mer <br>
              Route de la Plage,66700 Argelès-sur-Mer,<br>
              France <br>
              <strong>Téléphone: </strong> +33 4 68 81 55 55<br>
              <strong>Email: </strong> contact@supercamping-argeles.com<br>
            </p>

            <div class=\"social-links\">
              <a href=\"#\" class=\"twitter\"><i class=\"bi bi-twitter\"></i></a>
              <a href=\"#\" class=\"facebook\"><i class=\"bi bi-facebook\"></i></a>
              <a href=\"#\" class=\"instagram\"><i class=\"bi bi-instagram\"></i></a>
              <a href=\"#\" class=\"linkedin\"><i class=\"bi bi-linkedin\"></i></a>
            </div>

          </div>

          <div class=\"col-lg-3 col-md-6 footer-newsletter\">
          <h4>Notre Newsletter</h4>
          <p>Restez informé des dernières nouveautés et offres spéciales de notre camping. Inscrivez-vous à notre newsletter pour recevoir des informations exclusives directement dans votre boîte mail.</p>
          <form action=\"\" method=\"post\">
            <input type=\"email\" name=\"email\" placeholder=\"Votre adresse email\"><input type=\"submit\" value=\"S'inscrire\">
          </form>
        </div>


        </div>
      </div>
    </div>

    <div class=\"container\">
    <div class=\"copyright\">
      &copy; Copyright <strong><span>Super Camping d'Argelès-sur-Mer</span></strong>. Tous droits réservés
    </div>
    <div class=\"credits\">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/serenity-bootstrap-corporate-template/ -->
    </div>
</div>

  </footer>", "payment/partials/footer.html.twig", "/home/formatpro/Bureau/Camping Serenity/Camping/templates/payment/partials/footer.html.twig");
    }
}
