<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* price/partials/faq.html.twig */
class __TwigTemplate_385d190fe03d057f9f161473eb15029b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "price/partials/faq.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "price/partials/faq.html.twig"));

        yield "<section id=\"faq\" class=\"faq section-bg\">
    <div class=\"container\">

        <div class=\"section-title\" data-aos=\"fade-up\">
            <h2>Questions Fréquemment Posées</h2>
            <p>Vous trouverez ci-dessous les réponses aux questions les plus courantes concernant nos tarifs et nos services de camping. Si vous avez d'autres questions, n'hésitez pas à nous contacter.</p>
        </div>

        <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\">
            <div class=\"col-lg-5\">
                <i class=\"bx bx-tent\"></i>
                <h4>Quels services sont inclus dans le tarif de l'emplacement tente ?</h4>
            </div>
            <div class=\"col-lg-7\">
                <p>
                    Le tarif de l'emplacement tente inclut l'accès aux sanitaires, le Wi-Fi gratuit, et l'accès à la zone de barbecue. L'électricité n'est pas incluse.
                </p>
            </div>
        </div><!-- End F.A.Q Item-->

        <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\" data-aos-delay=\"100\">
            <div class=\"col-lg-5\">
                <i class=\"bx bx-caravan\"></i>
                <h4>Les emplacements pour caravanes incluent-ils l'électricité ?</h4>
            </div>
            <div class=\"col-lg-7\">
                <p>
                    Oui, les emplacements pour caravanes incluent l'électricité, ainsi que l'accès aux sanitaires, le Wi-Fi gratuit et l'accès à la zone de barbecue.
                </p>
            </div>
        </div><!-- End F.A.Q Item-->

        <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\" data-aos-delay=\"200\">
            <div class=\"col-lg-5\">
                <i class=\"bx bx-calendar\"></i>
                <h4>Quelles sont les conditions de réservation ?</h4>
            </div>
            <div class=\"col-lg-7\">
                <p>
                    Pour réserver votre emplacement, un acompte de 50% est requis. L'annulation est gratuite jusqu'à 30 jours avant la date d'arrivée. Pour les annulations entre 15 et 30 jours, 50% de l'acompte est remboursé. Aucun remboursement n'est effectué pour les annulations moins de 15 jours avant l'arrivée.
                </p>
            </div>
        </div><!-- End F.A.Q Item-->

        <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\" data-aos-delay=\"300\">
            <div class=\"col-lg-5\">
                <i class=\"bx bx-run\"></i>
                <h4>Y a-t-il des activités disponibles sur le camping ?</h4>
            </div>
            <div class=\"col-lg-7\">
                <p>
                    Oui, nous proposons une variété d'activités, y compris des sentiers de randonnée, des aires de jeux pour enfants, et des espaces pour le volley-ball et le badminton.
                </p>
            </div>
        </div><!-- End F.A.Q Item-->

        <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\" data-aos-delay=\"400\">
            <div class=\"col-lg-5\">
                <i class=\"bx bx-paw\"></i>
                <h4>Y a-t-il des restrictions pour les animaux de compagnie ?</h4>
            </div>
            <div class=\"col-lg-7\">
                <p>
                    Les animaux de compagnie sont les bienvenus sur le camping. Cependant, ils doivent être tenus en laisse et ne pas déranger les autres campeurs. Nous vous demandons de nettoyer après vos animaux.
                </p>
            </div>
        </div><!-- End F.A.Q Item-->

    </div>
</section><!-- End Frequently Asked Questions Section -->

";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "price/partials/faq.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Source("<section id=\"faq\" class=\"faq section-bg\">
    <div class=\"container\">

        <div class=\"section-title\" data-aos=\"fade-up\">
            <h2>Questions Fréquemment Posées</h2>
            <p>Vous trouverez ci-dessous les réponses aux questions les plus courantes concernant nos tarifs et nos services de camping. Si vous avez d'autres questions, n'hésitez pas à nous contacter.</p>
        </div>

        <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\">
            <div class=\"col-lg-5\">
                <i class=\"bx bx-tent\"></i>
                <h4>Quels services sont inclus dans le tarif de l'emplacement tente ?</h4>
            </div>
            <div class=\"col-lg-7\">
                <p>
                    Le tarif de l'emplacement tente inclut l'accès aux sanitaires, le Wi-Fi gratuit, et l'accès à la zone de barbecue. L'électricité n'est pas incluse.
                </p>
            </div>
        </div><!-- End F.A.Q Item-->

        <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\" data-aos-delay=\"100\">
            <div class=\"col-lg-5\">
                <i class=\"bx bx-caravan\"></i>
                <h4>Les emplacements pour caravanes incluent-ils l'électricité ?</h4>
            </div>
            <div class=\"col-lg-7\">
                <p>
                    Oui, les emplacements pour caravanes incluent l'électricité, ainsi que l'accès aux sanitaires, le Wi-Fi gratuit et l'accès à la zone de barbecue.
                </p>
            </div>
        </div><!-- End F.A.Q Item-->

        <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\" data-aos-delay=\"200\">
            <div class=\"col-lg-5\">
                <i class=\"bx bx-calendar\"></i>
                <h4>Quelles sont les conditions de réservation ?</h4>
            </div>
            <div class=\"col-lg-7\">
                <p>
                    Pour réserver votre emplacement, un acompte de 50% est requis. L'annulation est gratuite jusqu'à 30 jours avant la date d'arrivée. Pour les annulations entre 15 et 30 jours, 50% de l'acompte est remboursé. Aucun remboursement n'est effectué pour les annulations moins de 15 jours avant l'arrivée.
                </p>
            </div>
        </div><!-- End F.A.Q Item-->

        <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\" data-aos-delay=\"300\">
            <div class=\"col-lg-5\">
                <i class=\"bx bx-run\"></i>
                <h4>Y a-t-il des activités disponibles sur le camping ?</h4>
            </div>
            <div class=\"col-lg-7\">
                <p>
                    Oui, nous proposons une variété d'activités, y compris des sentiers de randonnée, des aires de jeux pour enfants, et des espaces pour le volley-ball et le badminton.
                </p>
            </div>
        </div><!-- End F.A.Q Item-->

        <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\" data-aos-delay=\"400\">
            <div class=\"col-lg-5\">
                <i class=\"bx bx-paw\"></i>
                <h4>Y a-t-il des restrictions pour les animaux de compagnie ?</h4>
            </div>
            <div class=\"col-lg-7\">
                <p>
                    Les animaux de compagnie sont les bienvenus sur le camping. Cependant, ils doivent être tenus en laisse et ne pas déranger les autres campeurs. Nous vous demandons de nettoyer après vos animaux.
                </p>
            </div>
        </div><!-- End F.A.Q Item-->

    </div>
</section><!-- End Frequently Asked Questions Section -->

", "price/partials/faq.html.twig", "/home/formatpro/Bureau/Camping Serenity/Camping/templates/price/partials/faq.html.twig");
    }
}
