<?php

namespace App\Controller;

use Stripe\Stripe;
use Stripe\Checkout\Session;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

class StripeController extends AbstractController
{
    #[Route('/create-checkout-session', name: 'create_checkout_session')]
    public function createCheckoutSession(Request $request, UrlGeneratorInterface $urlGenerator)
    {
        Stripe::setApiKey('sk_test_51PY4LwDzMg6ykNYFOM27Sh0Y1KylOwPYqlSiOIf0az66NgCq00E1l2npAApETaO4K4ZNZYaAq3zdaxWqiXZkCpy500JPL5qTMv');

        $data = json_decode($request->getContent(), true);
        $price = $data['price'];
        $checkInDate = $data['check_in_date'];
        $checkOutDate = $data['check_out_date'];
        $logementType = $data['logement_type'];

        try {
            $checkout_session = Session::create([
                'payment_method_types' => ['card'],
                'line_items' => [[
                    'price_data' => [
                        'currency' => 'eur',
                        'product_data' => [
                            'name' => 'Camping Reservation',
                        ],
                        'unit_amount' => $price, // Amount in cents
                    ],
                    'quantity' => 1,
                ]],
                'mode' => 'payment',
                'metadata' => [
                    'check_in_date' => $checkInDate,
                    'check_out_date' => $checkOutDate,
                    'logement_type' => $logementType
                ],
                'success_url' => $urlGenerator->generate('success_url', [], UrlGeneratorInterface::ABSOLUTE_URL) . '?session_id={CHECKOUT_SESSION_ID}',
                'cancel_url' => $urlGenerator->generate('cancel_url', [], UrlGeneratorInterface::ABSOLUTE_URL),
            ]);

            return new JsonResponse(['id' => $checkout_session->id]);
        } catch (\Exception $e) {
            error_log("Error creating Stripe session: " . $e->getMessage());
            return new JsonResponse(['error' => $e->getMessage()], 500);
        }
    }




    #[Route('/success', name: 'success_url')]
    public function success(Request $request)
    {
        Stripe::setApiKey('sk_test_51PY4LwDzMg6ykNYFOM27Sh0Y1KylOwPYqlSiOIf0az66NgCq00E1l2npAApETaO4K4ZNZYaAq3zdaxWqiXZkCpy500JPL5qTMv');
        
        $sessionId = $request->query->get('session_id');
        try {
            $session = Session::retrieve($sessionId);
            $checkInDate = $session->metadata->check_in_date;
            $checkOutDate = $session->metadata->check_out_date;
            $logementType = $session->metadata->logement_type;
            $totalPrice = $session->amount_total / 100;

            return $this->render('payment/partials/succes.html.twig', [
                'check_in_date' => $checkInDate,
                'check_out_date' => $checkOutDate,
                'logement_type' => $logementType,
                'total_price' => $totalPrice,
            ]);
        } catch (\Exception $e) {
            error_log("Error retrieving Stripe session: " . $e->getMessage());
            return new JsonResponse(['error' => $e->getMessage()], 500);
        }
    }




    #[Route('/cancel', name: 'cancel_url')]
    public function cancel(Request $request)
    {
        // Retrieve details from session or another means
        $checkInDate = $request->query->get('check_in_date');
        $checkOutDate = $request->query->get('check_out_date');
        $logementType = $request->query->get('logement_type');
        $totalPrice = $request->query->get('total_price');

        return $this->render('payment/partials/cancel.html.twig', [
            'check_in_date' => $checkInDate,
            'check_out_date' => $checkOutDate,
            'logement_type' => $logementType,
            'total_price' => $totalPrice,
        ]);
    }

}


